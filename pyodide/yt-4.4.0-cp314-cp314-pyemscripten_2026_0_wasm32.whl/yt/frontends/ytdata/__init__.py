"""
API for ytData frontend.




"""
