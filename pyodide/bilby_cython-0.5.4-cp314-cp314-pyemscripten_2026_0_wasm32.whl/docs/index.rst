bilby-cython
============

A collection of optimized tools for functionality causing bottlenecks in `Bilby <docs.ligo.org/lscsoft/bilby/>`_.

.. toctree::
   :maxdepth: 2

   geometry
   time


Installation
------------

.. tab-set::

  .. tab-item:: Conda

    .. code-block:: console

      $ conda install -c conda-forge bilby.cython

  .. tab-item:: Pip

    .. code-block:: console

      $ pip install bilby.cython

  .. tab-item:: Source

    .. code-block:: console

      $ git clone git@git.ligo.org:colm.talbot/bilby-cython.git
      $ cd bilby-cython
      $ pip install .

  .. tab-item:: Develop

    .. code-block:: console

      $ git clone git@git.ligo.org:colm.talbot/bilby-cython.git
      $ cd bilby-cython
      $ pip install -e .
