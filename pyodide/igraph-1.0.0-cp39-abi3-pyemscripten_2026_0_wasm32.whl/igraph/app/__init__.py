"""User interfaces of igraph"""
