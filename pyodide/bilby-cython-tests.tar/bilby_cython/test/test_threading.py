def run_threaded(
    func,
    args,
    num_threads=8,
):
    from concurrent.futures import ThreadPoolExecutor
    """Runs a function many times in parallel"""
    with ThreadPoolExecutor(max_workers=num_threads) as tpe:
        all_args = list()
        for arg, mode in zip(*args):
            all_args.append((func, *arg, str(mode)))
        futures = []
        for arg in all_args:
            futures.append(tpe.submit(*arg))
        for f in futures:
            f.result()
    return [f.result() for f in futures]


def test_parallel():
    import numpy as np
    from bilby_cython import geometry

    test_points = np.random.uniform(0, np.pi / 2, (10000, 4))
    modes = np.random.choice(["plus", "cross", "x", "y", "breathing", "longitudinal"], len(test_points))

    tensors = []
    for (ra, dec, time, psi), mode in zip(test_points, modes):
        args = (ra, dec, time, psi, str(mode))
        tensor = geometry.get_polarization_tensor(*args)
        tensors.append(tensor)
    tensors = np.array(tensors)

    threaded_tensors = np.array(run_threaded(
        geometry.get_polarization_tensor, (test_points, modes), num_threads=8
    ))

    assert np.allclose(tensors, threaded_tensors, atol=1e-12)


if __name__ == "__main__":
    test_parallel()