mupdf_location = 'https://mupdf.com/downloads/archive/mupdf-1.27.2-source.tar.gz'
pymupdf_version = '1.27.2.2'
pymupdf_version_tuple = (1, 27, 2, 2)
pymupdf_git_sha = '732e33c363c22adc15500d6a064ba9db424f6332'
pymupdf_git_diff = ''
pymupdf_git_branch = 'HEAD'
swig_version = '4.4.1'
swig_version_tuple = (4, 4, 1)
